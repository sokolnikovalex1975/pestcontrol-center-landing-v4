<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Пест-контроль и пест-менеджмент для бизнеса в Москве и области — ПЕСТКОНТРОЛЬ Центр</title>
<meta name="description" content="Пест-контроль и пест-менеджмент по системе IPM для предприятий Москвы и области: бесплатный аудит и оценка пест-риска, программа пест-контроля, мониторинг вредителей и прогноз численности.">
<meta name="theme-color" content="#000000">
<meta property="og:type" content="website">
<meta property="og:locale" content="ru_RU">
<meta property="og:site_name" content="ПЕСТКОНТРОЛЬ Центр">
<meta property="og:title" content="Пест-контроль и пест-менеджмент для бизнеса в Москве и области">
<meta property="og:description" content="Пест-менеджмент по системе IPM на пищевых и фармацевтических производствах, в торговых сетях, ресторанах, на складах и в гостиницах: бесплатный аудит, оценка пест-риска, программа, мониторинг и документы.">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Ccircle cx='16' cy='16' r='15' fill='%2309090b' stroke='%237c86ff' stroke-width='2'/%3E%3Cpath d='M16 7l7 3v5c0 5-3 8.5-7 10-4-1.5-7-5-7-10v-5z' fill='none' stroke='%23fff' stroke-width='2'/%3E%3C/svg%3E">
<link rel="preload" href="fonts/inter-cyrillic-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="img/hero.webp" as="image" media="(min-width:761px)">
<link rel="preload" href="img/hero-m.webp" as="image" media="(max-width:760px)">
<script>
  /* включаем начальные состояния анимаций только при работающем JS; страховка — через 4 с всё показывается */
  document.documentElement.classList.add('js');
  setTimeout(function(){ if(!document.documentElement.classList.contains('anim-ready')) document.documentElement.classList.add('anim-fail'); }, 4000);
</script>
<link rel="canonical" href="https://xn----itbbsflddbfpfdodg9d0f.xn--p1ai/">
<link rel="stylesheet" href="style.css?v=20261020v4">
<!-- UIS -->
    <script type="text/javascript" async src="https://app.uiscom.ru/static/cs.min.js?k=ICWycQx6m3NSBe3WlCeDAdAKMTmNhMHC"></script>
<!-- UIS -->
</head>
<body>
<a class="skip" href="#main">Перейти к содержанию</a>

<!-- ============ INTRO ============ -->
<div class="intro" id="intro" aria-hidden="true">
  <div class="intro-in">
    <svg class="intro-mark" viewBox="0 0 24 24" fill="none" stroke-width="1" stroke-linejoin="round"><path class="im-shield" pathLength="100" d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z" stroke="#fff"/><circle class="im-c" pathLength="100" cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path class="im-x" pathLength="100" d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg>
    <div class="intro-word"><span>ПЕСТКОНТРОЛЬ</span><b>Центр</b></div>
    <div class="intro-bar"><i></i></div>
  </div>
</div>

<div class="progress" aria-hidden="true"><i id="progress"></i></div>
<div class="cursor" aria-hidden="true"><i class="cursor-dot"></i><i class="cursor-ring"></i></div>
<div class="grain" aria-hidden="true"></div>

<!-- ============ HEADER ============ -->
<header class="hdr" id="hdr">
  <div class="wrap">
    <a href="#top" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — на главную">
      <span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span>
      <span><span class="logo-name">ПЕСТКОНТРОЛЬ</span><span class="logo-sub">Центр</span></span>
    </a>
    <nav class="nav" aria-label="Основное меню">
      <a href="#etapy">Этапы</a><a href="#podhod">IPM</a><a href="#dokumenty">Документы</a><a href="#otrasli">Объекты</a><a href="#usloviya">Цена</a><a href="#voprosy">Вопросы</a>
    </nav>
    <div class="hdr-right">
      <a class="phone" href="tel:+74951043570" aria-label="Позвонить: +7 (495) 104-35-70"><i><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></i><span>+7 (495) 104-35-70</span></a>
      <div class="msg">
        <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
        <a href="https://t.me/Centr_Dezinfection" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
      </div>
      <a href="#zayavka" class="btn btn-w btn-sm" data-magnet><span class="btn-t">Бесплатный аудит</span></a>
      <button class="burger" id="burger" aria-label="Открыть меню" aria-expanded="false" aria-controls="mmenu"><span></span></button>
    </div>
  </div>
</header>
<nav class="mmenu" id="mmenu" aria-label="Мобильное меню">
  <a href="#etapy">Этапы работы</a><a href="#podhod">Метод IPM</a><a href="#dokumenty">Документы</a><a href="#otrasli">Объекты</a><a href="#vrediteli">Вредители</a><a href="#usloviya">Цена</a><a href="#voprosy">Вопросы</a>
  <a href="#zayavka" class="btn btn-w btn-lg"><span class="btn-t">Заказать бесплатный аудит</span></a>
</nav>

<main id="main" tabindex="-1">
<span id="top"></span>

<!-- ============ 1. HERO ============ -->
<section class="hero" id="hero">
  <div class="hero-media" id="heroMedia" aria-hidden="true">
    <div class="hero-bg"></div>
    <div class="hero-lit" id="heroLit"></div>
  </div>
  <div class="wrap">
    <div class="hero-copy" id="heroCopy">
      <span class="badge" data-h><span class="dot"></span>Пест-менеджмент по системе IPM</span>
      <h1>
        <span class="ln"><span><span class="nw">Пест-контроль</span></span></span>
        <span class="ln"><span>для бизнеса</span></span>
        <span class="ln"><span><em>в Москве и области</em></span></span>
      </h1>
      <p class="lead" data-h>Берём объект на постоянное обслуживание по системе IPM. Начинаем с бесплатного аудита и оценки <span class="nw">пест-риска</span>, затем составляем программу <span class="nw">пест-контроля</span> и ведём мониторинг вредителей по графику. Обработки — только по показаниям.</p>
      <div class="hero-ctas" data-h>
        <a href="#zayavka" class="btn btn-w btn-lg" data-magnet><span class="btn-t">Заказать бесплатный аудит</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
        <a href="#etapy" class="btn btn-o btn-lg" data-magnet><span class="btn-t">Как мы работаем</span></a>
      </div>
    </div>
    <aside class="panel" id="panel" aria-label="Что покажет бесплатный аудит">
      <div class="panel-scan" aria-hidden="true"></div>
      <div class="panel-glare" aria-hidden="true"></div>
      <div class="panel-h"><b>Что покажет бесплатный аудит</b><small>выезд · 0 ₽</small></div>
      <ul>
        <li><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg></span><div><strong>Активность и очаги</strong><span>Следы вредителей, места укрытий и размножения — с фотофиксацией</span></div></li>
        <li><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-door-open" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M10 21H2" /> <path d="M10 3H7a2 2 0 00-2 2v16" /> <path d="M14 12h.01" /> <path d="M19 21V5a2 2 0 00-1.675-1.974l-6.163-1.013A1 1 0 0010 3v18a1 1 0 001.124.992z" /> <path d="M22 21h-3" /> </svg></span><div><strong>Пути проникновения</strong><span>Щели, вводы коммуникаций, ворота и вентиляция</span></div></li>
        <li><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-list-checks" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 5h8" /> <path d="M13 12h8" /> <path d="M13 19h8" /> <path d="m3 17 2 2 4-4" /> <path d="m3 7 2 2 4-4" /> </svg></span><div><strong>Что привлекает вредителей</strong><span>Хранение, уборка, отходы — и что из этого исправить</span></div></li>
        <li><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-map" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z" /> <path d="M15 5.764v15" /> <path d="M9 3.236v15" /> </svg></span><div><strong>Оценка пест-риска по зонам</strong><span>Где нужны станции, ловушки и лампы — основа будущей схемы</span></div></li>
        <li><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-calculator" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="16" height="20" x="4" y="2" rx="2" /> <line x1="8" x2="16" y1="6" y2="6" /> <line x1="16" x2="16" y1="14" y2="18" /> <path d="M16 10h.01" /> <path d="M12 10h.01" /> <path d="M8 10h.01" /> <path d="M12 14h.01" /> <path d="M8 14h.01" /> <path d="M12 18h.01" /> <path d="M8 18h.01" /> </svg></span><div><strong>Программа и стоимость</strong><span>Периодичность визитов и цена регулярного обслуживания</span></div></li>
      </ul>
    </aside>
  </div>
  <a href="#zadachi" class="scroll-cue" data-h aria-label="Прокрутить к следующему блоку"><span>Листайте</span><i></i></a>
</section>

<!-- ============ 2. STRIP ============ -->
<div class="strip" aria-label="Стандарт обслуживания">
  <div class="strip-track" id="stripTrack">
    <div class="strip-set">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> система пест-менеджмента</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатный аудит</b> до договора</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Договор</b> с графиком визитов</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>Схема точек</b> на плане объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Мониторинг вредителей</b> по графику</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акт</b> после каждого визита</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> дезинсекция и дератизация</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>ХАССП</b> программа пест-контроля</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-award" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526" /> <circle cx="12" cy="8" r="6" /> </svg><b>GMP</b> защита помещений от вредителей</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-flask-conical" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" /> <path d="M6.453 15h11.094" /> <path d="M8.5 2h7" /> </svg><b>Средства с СГР</b> строго по инструкции</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-globe" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /> <path d="M2 12h20" /> </svg><b>Москва и область</b> выезд на объект</div>
    </div>
    <div class="strip-set" aria-hidden="true">
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg><b>IPM</b> система пест-менеджмента</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-scan-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 7V5a2 2 0 0 1 2-2h2" /> <path d="M17 3h2a2 2 0 0 1 2 2v2" /> <path d="M21 17v2a2 2 0 0 1-2 2h-2" /> <path d="M7 21H5a2 2 0 0 1-2-2v-2" /> <circle cx="12" cy="12" r="3" /> <path d="m16 16-1.9-1.9" /> </svg><b>Бесплатный аудит</b> до договора</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg><b>Договор</b> с графиком визитов</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg><b>Схема точек</b> на плане объекта</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-activity" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" /> </svg><b>Мониторинг вредителей</b> по графику</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg><b>Журнал и акт</b> после каждого визита</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-badge" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3" /> <path d="M14 2v5a1 1 0 0 0 1 1h5" /> <path d="m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88" /> <circle cx="6" cy="14" r="3" /> </svg><b>СанПиН 3.3686-21</b> дезинсекция и дератизация</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-shield-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /> <path d="m9 12 2 2 4-4" /> </svg><b>ХАССП</b> программа пест-контроля</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-award" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526" /> <circle cx="12" cy="8" r="6" /> </svg><b>GMP</b> защита помещений от вредителей</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-flask-conical" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2" /> <path d="M6.453 15h11.094" /> <path d="M8.5 2h7" /> </svg><b>Средства с СГР</b> строго по инструкции</div>
      <div class="strip-item"><svg aria-hidden="true" focusable="false" class="lucide lucide-globe" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" /> <path d="M2 12h20" /> </svg><b>Москва и область</b> выезд на объект</div>
    </div>
  </div>
</div>

<!-- ============ 3. СИТУАЦИИ ============ -->
<section class="s" id="zadachi">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Ситуации</div>
      <h2 data-split>Когда нужен <em>постоянный <span class="nw">пест-контроль</span></em></h2>
      <p class="sub" data-scrub>Обработки на всех трёх объектах уже проводили. Но без регулярного наблюдения вредители возвращаются, а показать проверяющему можно только разовые акты.</p>
    </div>
    <div class="tasks" data-group="tasks">
      <article class="card task">
        <span class="chip-y">Аудит сети</span>
        <q>Сеть назначила аудит поставщика. По <span class="nw">пест-контролю</span> у нас только акты разовых обработок — ни схемы точек, ни журнала осмотров.</q>
        <div class="who"><span class="ava"><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg></span><div><b>Служба качества</b><span>Пищевое производство</span></div></div>
      </article>
      <article class="card task">
        <span class="chip-y">Снова на кухне</span>
        <q>Кухню обрабатывают каждый месяц, а через пару недель тараканы снова у мойки. Хотим понять, откуда они приходят.</q>
        <div class="who"><span class="ava"><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg></span><div><b>Управляющий</b><span>Ресторан</span></div></div>
      </article>
      <article class="card task">
        <span class="chip-y">Претензия клиента</span>
        <q>На приёмке нашли погрызенную упаковку. Клиент просит подтвердить, что на складе ведётся контроль грызунов.</q>
        <div class="who"><span class="ava"><svg aria-hidden="true" focusable="false" class="lucide lucide-warehouse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11" /> <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z" /> <path d="M6 13h12" /> <path d="M6 17h12" /> </svg></span><div><b>Руководитель склада</b><span>Логистический комплекс</span></div></div>
      </article>
    </div>
    <div class="tasks-foot" data-fade>
      <span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-lightbulb" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" /> <path d="M9 18h6" /> <path d="M10 22h4" /> </svg></span>
      <p>Узнали свою ситуацию? Начните с бесплатного аудита: специалист найдёт причину и предложит программу обслуживания для вашего объекта.</p>
      <a href="#zayavka" class="link-arrow">Заказать аудит <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a>
    </div>
  </div>
</section>

<!-- ============ 4. КАК РАБОТАЕМ ============ -->
<section class="s" id="etapy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Этапы работы</div>
      <h2 data-split>От бесплатного аудита <em>до регулярных визитов</em></h2>
      <p class="sub" data-fade>Два шага — до договора, два — уже в работе. На каждом понятно, что делаем мы и что получает объект.</p>
    </div>
    <div class="tl" id="tl">
      <div class="tl-line"><div class="tl-prog" id="tlprog"></div><i class="tl-head" id="tlhead"></i></div>
      <div class="tl-row">
        <div class="tl-txt"><div class="wk">Шаг 1</div><h3>Аудит и оценка <span class="nw">пест-риска</span></h3><p>Специалист бесплатно выезжает на объект, осматривает помещения и территорию, фотографирует следы активности и уязвимые места, оценивает <span class="nw">пест-риск</span> по зонам и смотрит, какие документы по <span class="nw">пест-контролю</span> у вас уже есть.</p></div>
        <div class="tl-img"><img width="1100" height="660" decoding="async" src="img/step1.webp" alt="Специалист осматривает оборудование на производстве" loading="lazy" data-parallax></div>
        <span class="tl-dot">01</span>
      </div>
      <div class="tl-row flip">
        <div class="tl-txt"><div class="wk">Шаг 2</div><h3>Программа <span class="nw">пест-контроля</span> и расчёт</h3><p>Составляем программу по принципам IPM: зоны контроля, оборудование, график визитов и средства с госрегистрацией. Называем стоимость и отдельно указываем, что входит в обслуживание, а что согласуется дополнительно.</p></div>
        <div class="tl-img"><img width="1100" height="660" decoding="async" src="img/step2.webp" alt="Схема станций и журналы учёта" loading="lazy" data-parallax></div>
        <span class="tl-dot">02</span>
      </div>
      <div class="tl-row">
        <div class="tl-txt"><div class="wk">Шаг 3</div><h3>Запуск контроля</h3><p>После подписания договора ставим и нумеруем станции, ловушки и лампы, наносим их на план и заводим журнал. Если есть активный очаг — сначала обрабатываем его.</p></div>
        <div class="tl-img"><img width="500" height="300" decoding="async" src="img/step3.webp" alt="Установка станции для грызунов" loading="lazy" data-parallax></div>
        <span class="tl-dot">03</span>
      </div>
      <div class="tl-row flip">
        <div class="tl-txt"><div class="wk">Шаг 4</div><h3>Регулярные визиты</h3><p>Осматриваем точки по графику, записываем результаты, корректируем программу, присылаем отчёт за месяц и сообщаем, что исправить на объекте.</p></div>
        <div class="tl-img"><img width="1100" height="660" decoding="async" src="img/step4.webp" alt="Специалист проверяет станцию и заполняет журнал" loading="lazy" data-parallax></div>
        <span class="tl-dot">04</span>
      </div>
    </div>
  </div>
</section>

<!-- ============ 5. МЕТОД (IPM) ============ -->
<section class="s" id="podhod">
  <div class="wrap appr">
    <div>
      <div>
        <div class="eyebrow" data-eyebrow>Метод IPM</div>
        <h2 data-split><span class="nw">Пест-менеджмент</span> <em>по системе IPM</em></h2>
        <p class="sub" data-scrub>IPM — интегрированная защита от вредителей: мониторинг и устранение причин вместо обработок по календарю, препараты — только по показаниям. На каждом визите специалист проходит четыре шага: осмотр, санитария, учёт, действие.</p>
      </div>
      <div class="steps" data-group="steps">
        <div class="card step" data-i="0"><span class="n">01</span><div><h3>Осматриваем точки контроля</h3><p>Проверяем каждую станцию, ловушку и лампу по схеме, фиксируем находки и следы активности.</p></div></div>
        <div class="card step" data-i="1"><span class="n">02</span><div><h3>Ищем, что привлекает вредителей</h3><p>Хранение сырья, уборка, отходы, протечки, щели и открытые проёмы. Рекомендации даём с фото; устраняет объект или мы — по отдельному согласованию.</p></div></div>
        <div class="card step" data-i="2"><span class="n">03</span><div><h3>Сравниваем и прогнозируем</h3><p>Сводим данные по точкам и зонам, сравниваем с прошлыми визитами и сезоном и делаем прогноз численности вредителей, чтобы усилить профилактику до вспышки.</p></div></div>
        <div class="card step" data-i="3"><span class="n">04</span><div><h3>Действуем по результатам</h3><p>Обрабатываем только очаг, подбираем средство под вид вредителя и чередуем действующие вещества, чтобы не возникала устойчивость.</p></div></div>
      </div>
    </div>
    <div class="cycle" id="cycle" aria-hidden="true">
      <div class="cycle-glow"></div><div class="cycle-ring"></div>
      <svg class="cycle-svg" viewBox="0 0 100 100"><circle class="cycle-track" cx="50" cy="50" r="38"/><circle class="cycle-prog" id="cycleProg" cx="50" cy="50" r="38" pathLength="100"/></svg>
      <div class="cycle-arc" id="cycleArc"></div>
      <div class="cycle-c"><div><b>IPM</b><span>цикл визита</span><em class="cycle-step" id="cycleStep">01 / 04</em></div></div>
      <div class="node n1" data-i="0"><i><svg aria-hidden="true" focusable="false" class="lucide lucide-search" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m21 21-4.34-4.34" /> <circle cx="11" cy="11" r="8" /> </svg></i><b>Осмотр</b></div>
      <div class="node n2" data-i="1"><i><svg aria-hidden="true" focusable="false" class="lucide lucide-spray-can" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 3h.01" /> <path d="M7 5h.01" /> <path d="M11 7h.01" /> <path d="M3 7h.01" /> <path d="M7 9h.01" /> <path d="M3 11h.01" /> <rect width="4" height="4" x="15" y="5" /> <path d="m19 9 2 2v10c0 .6-.4 1-1 1h-6c-.6 0-1-.4-1-1V11l2-2" /> <path d="m13 14 8-2" /> <path d="m13 19 8-2" /> </svg></i><b>Санитария</b></div>
      <div class="node n3" data-i="2"><i><svg aria-hidden="true" focusable="false" class="lucide lucide-chart-column" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 3v16a2 2 0 0 0 2 2h16" /> <path d="M18 17V9" /> <path d="M13 17V5" /> <path d="M8 17v-3" /> </svg></i><b>Учёт</b></div>
      <div class="node n4" data-i="3"><i><svg aria-hidden="true" focusable="false" class="lucide lucide-crosshair" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <line x1="22" x2="18" y1="12" y2="12" /> <line x1="6" x2="2" y1="12" y2="12" /> <line x1="12" x2="12" y1="6" y2="2" /> <line x1="12" x2="12" y1="22" y2="18" /> </svg></i><b>Действие</b></div>
    </div>
  </div>
</section>

<!-- ============ 6. ДОКУМЕНТЫ ============ -->
<section class="s" id="dokumenty">
  <div class="wrap">
    <div class="head head-row">
      <div>
        <div class="eyebrow" data-eyebrow>Документы</div>
        <h2 data-split>Документы по программе <em><span class="nw">пест-контроля</span></em></h2>
      </div>
      <p class="sub sub-side" data-fade>Ведём записи по каждому визиту и держим пакет в актуальном виде. Состав согласуем под объект и требования вашей системы качества.</p>
    </div>
    <div class="docs" data-group="docs">
      <article class="card doc"><span class="num">01</span><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-file-signature" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z" /> <path d="M14.487 7.858A1 1 0 0 1 14 7V2" /> <path d="M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516" /> <path d="M8 18h1" /> </svg></span><h3>Договор и программа</h3><p>Объекты, зоны контроля, периодичность визитов и ответственные. Основа раздела <span class="nw">пест-контроля</span> в плане ХАССП или документации GMP.</p></article>
      <article class="card doc"><span class="num">02</span><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-map-pinned" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 01-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0112 0" /> <path d="M4.474 15h-.197a1 1 0 00-.969.753l-1.097 4.35a1.5 1.5 0 001.444 1.898L20.344 22a1.5 1.5 0 001.446-1.897l-1.098-4.35a1 1 0 00-.969-.753h-.197" /> <circle cx="12" cy="8" r="2" /> </svg></span><h3>Схема точек контроля</h3><p>План объекта с пронумерованными станциями, ловушками и лампами. Обновляем, когда точки переносим или добавляем.</p></article>
      <article class="card doc"><span class="num">03</span><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-notebook-pen" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4" /> <path d="M2 6h4" /> <path d="M2 10h4" /> <path d="M2 14h4" /> <path d="M2 18h4" /> <path d="M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z" /> </svg></span><h3>Журнал осмотров</h3><p>Дата, точка, находки и принятые меры — по каждому визиту.</p></article>
      <article class="card doc"><span class="num">04</span><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-clipboard-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <rect width="8" height="4" x="8" y="2" rx="1" ry="1" /> <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" /> <path d="m9 14 2 2 4-4" /> </svg></span><h3>Акты выполненных работ</h3><p>Что сделано, каким средством, в какой концентрации и с какими мерами безопасности.</p></article>
      <article class="card doc"><span class="num">05</span><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-badge-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z" /> <path d="m16 9-5.5 5.5L8 12" /> </svg></span><h3>СГР и инструкции</h3><p>Свидетельства о госрегистрации и инструкции на все средства, которые применяем на объекте.</p></article>
      <article class="card doc"><span class="num">06</span><span class="ico"><svg aria-hidden="true" focusable="false" class="lucide lucide-chart-line" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 3v16a2 2 0 0 0 2 2h16" /> <path d="m19 9-5 5-4-4-3 3" /> </svg></span><h3>Отчёт за месяц</h3><p>Динамика по зонам, прогноз численности вредителей, замечания по санитарии и что исправить до следующего визита.</p></article>
    </div>
  </div>
</section>

<!-- ============ 7. ОБЪЕКТЫ ============ -->
<section class="s" id="otrasli">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Объекты</div>
      <h2 data-split><span class="nw">Пест-контроль</span> под задачи <em>вашего объекта</em></h2>
      <p class="sub" data-fade>У пищевого и фармацевтического производства, ресторана и склада разные проверяющие, вредители и режим работы. Программу <span class="nw">пест-контроля</span> строим под это с первого выезда.</p>
    </div>
    <div class="inds" data-group="inds">
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" src="img/ind-bakery.webp" alt="Цех хлебозавода с инсектицидной лампой и станцией контроля грызунов" loading="lazy" data-parallax></div><div class="ind-b"><h3><svg aria-hidden="true" focusable="false" class="lucide lucide-factory" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M12 16h.01" /> <path d="M16 16h.01" /> <path d="M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z" /> <path d="M8 16h.01" /> </svg>Пищевые производства</h3><p>Мясо, молоко, хлеб, кондитерские изделия. Точки контроля по зонам ХАССП, закрытые станции в цехах, документы к аудиту сети и сертификации.</p><div class="tags"><span class="tag">ХАССП</span><span class="tag">FSSC 22000</span><span class="tag">ГОСТ Р ИСО 22000</span></div></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" src="img/ind-retail.webp" alt="Торговый зал супермаркета" loading="lazy" data-parallax></div><div class="ind-b"><h3><svg aria-hidden="true" focusable="false" class="lucide lucide-shopping-cart" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m2.05 2.05 1.099-.028a1 1 0 0 1 1.008.815l2.69 14.347A1 1 0 0 0 7.83 18H18" /> <path d="M4.563 5h16.435a1 1 0 0 1 .981 1.204l-1.026 6.226A2 2 0 0 1 18.962 14H6.25" /> <circle cx="18" cy="20" r="2" /> <circle cx="8" cy="20" r="2" /> </svg>Торговые сети</h3><p>Несколько адресов — один стандарт: общая программа, единый график и сводная отчётность по всем магазинам.</p><div class="tags"><span class="tag">Сети</span><span class="tag">Сводный отчёт</span></div></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" src="img/ind-kitchen.webp" alt="Специалист осматривает кухню ресторана после закрытия" loading="lazy" data-parallax></div><div class="ind-b"><h3><svg aria-hidden="true" focusable="false" class="lucide lucide-utensils" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" /> <path d="M7 2v20" /> <path d="M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" /> </svg>Рестораны и кафе</h3><p>Тараканы и мухи на кухне, в мойке и на складе. Работаем после закрытия, время возобновления работы согласуем по инструкции к средству.</p><div class="tags"><span class="tag">После закрытия</span><span class="tag">СанПиН</span></div></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" src="img/ind-warehouse.webp" alt="Складской комплекс" loading="lazy" data-parallax></div><div class="ind-b"><h3><svg aria-hidden="true" focusable="false" class="lucide lucide-warehouse" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11" /> <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z" /> <path d="M6 13h12" /> <path d="M6 17h12" /> </svg>Склады и логистика</h3><p>Рампы и зоны приёмки, контроль грызунов снаружи и внутри здания, мониторинг по зонам хранения.</p><div class="tags"><span class="tag">Рампы</span><span class="tag">Грызуны</span></div></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" src="img/ind-pharma.webp" alt="Коридор фармацевтического производства" loading="lazy" data-parallax></div><div class="ind-b"><h3><svg aria-hidden="true" focusable="false" class="lucide lucide-pill" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z" /> <path d="m8.5 8.5 7 7" /> </svg>Фармацевтические производства</h3><p>Чистые помещения, склады субстанций и готовой продукции. Внутри — только ловушки без яда, приманки — по внешнему периметру. Документы для GMP-инспекций и аудитов заказчиков.</p><div class="tags"><span class="tag">GMP</span><span class="tag">Чистые помещения</span></div></div></article>
      <article class="card ind" data-tilt><div class="ind-img"><img width="900" height="542" decoding="async" src="img/ind-hotel-room.webp" alt="Специалист проверяет швы матраса в гостиничном номере" loading="lazy" data-parallax></div><div class="ind-b"><h3><svg aria-hidden="true" focusable="false" class="lucide lucide-bed-double" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8" /> <path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4" /> <path d="M12 4v6" /> <path d="M2 18h20" /> </svg>Гостиницы</h3><p>Плановые осмотры номерного фонда, срочный выезд по сообщению гостя, обучение горничных признакам клопов.</p><div class="tags"><span class="tag">Клопы</span><span class="tag">Без огласки</span></div></div></article>
    </div>
  </div>
</section>

<!-- ============ 8. ВРЕДИТЕЛИ ============ -->
<section class="s pests-s" id="vrediteli">
  <div class="pests-bg" data-parallax-bg aria-hidden="true"></div>
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Вредители</div>
      <h2 data-split>Грызуны, насекомые <em>и птицы</em></h2>
      <p class="sub" data-fade>Дератизация и дезинсекция в программе — по данным мониторинга вредителей. Для каждого вида свои точки контроля и признаки, которые может заметить персонал.</p>
    </div>
    <div class="pests" data-group="pests">
      <article class="card pest">
        <div class="pest-img"><img width="240" height="240" decoding="async" src="img/p-cockroach.webp" alt="Рыжий таракан" loading="lazy"><i class="scan" aria-hidden="true"></i></div>
        <div class="pest-b">
          <div class="pest-t"><h3>Тараканы</h3><span class="lvl z">Кухня · мойка</span></div>
          <div class="lat">Признаки: тёмные точки помёта, оотеки, особи ночью у тепла и воды</div>
          <p>Прячутся в тёплых щелях у оборудования, в коробах и под мойками. Мониторы показывают, где очаг, поэтому обрабатываем точечно, а не всё помещение.</p>
          <div class="bar"><div class="bar-l"><span>Контроль: клеевые мониторы, гелевые приманки</span></div></div>
        </div>
      </article>
      <article class="card pest">
        <div class="pest-img"><img width="240" height="240" decoding="async" src="img/p-rat.webp" alt="Серая крыса" loading="lazy"><i class="scan" aria-hidden="true"></i></div>
        <div class="pest-b">
          <div class="pest-t"><h3>Крысы и мыши</h3><span class="lvl z">Склад · периметр</span></div>
          <div class="lat">Признаки: помёт, погрызы упаковки и кабеля, жирные следы вдоль стен</div>
          <p>Портят сырьё и упаковку, повреждают проводку, переносят инфекции. Станции закрытые: приманка недоступна людям и продукции.</p>
          <div class="bar"><div class="bar-l"><span>Контроль: станции с приманкой, ловушки</span></div></div>
        </div>
      </article>
      <article class="card pest">
        <div class="pest-img"><img width="240" height="240" decoding="async" src="img/p-fly.webp" alt="Комнатная муха" loading="lazy"><i class="scan" aria-hidden="true"></i></div>
        <div class="pest-b">
          <div class="pest-t"><h3>Мухи и дрозофилы</h3><span class="lvl z">Отходы · сливы</span></div>
          <div class="lat">Признаки: скопления у контейнеров, сливов, фруктов и тары</div>
          <p>Летят на запах отходов и брожения. Массовые дрозофилы почти всегда указывают на проблему с уборкой, сливами или хранением.</p>
          <div class="bar"><div class="bar-l"><span>Контроль: светоловушки, санитарные меры</span></div></div>
        </div>
      </article>
      <article class="card pest">
        <div class="pest-img"><img width="240" height="240" decoding="async" src="img/p-moth.webp" alt="Пищевая моль — южная амбарная огнёвка" loading="lazy"><i class="scan" aria-hidden="true"></i></div>
        <div class="pest-b">
          <div class="pest-t"><h3>Пищевая моль</h3><span class="lvl z">Сухое сырьё</span></div>
          <div class="lat">Признаки: бабочки на стенах и у потолка, паутинка и комки в муке, крупе и сухофруктах</div>
          <p>Чаще всего это южная амбарная огнёвка. Гусеницы портят муку, крупы, сухофрукты и корма и оставляют паутину — партия уходит в брак.</p>
          <div class="bar"><div class="bar-l"><span>Контроль: феромонные ловушки, осмотр партий</span></div></div>
        </div>
      </article>
      <article class="card pest">
        <div class="pest-img"><img width="240" height="240" decoding="async" src="img/p-bedbug-macro.webp" alt="Постельный клоп" loading="lazy"><i class="scan" aria-hidden="true"></i></div>
        <div class="pest-b">
          <div class="pest-t"><h3>Постельные клопы</h3><span class="lvl z">Номерной фонд</span></div>
          <div class="lat">Признаки: тёмные точки в швах матрасов, следы укусов у гостей</div>
          <p>Попадают в номера с багажом гостей и вещами персонала. Важно найти очаг до отзывов: проверяем номер и соседние.</p>
          <div class="bar"><div class="bar-l"><span>Контроль: осмотр номеров, обучение горничных</span></div></div>
        </div>
      </article>
      <article class="card pest">
        <div class="pest-img"><img width="240" height="240" decoding="async" src="img/p-pigeon.webp" alt="Сизый голубь" loading="lazy"><i class="scan" aria-hidden="true"></i></div>
        <div class="pest-b">
          <div class="pest-t"><h3>Голуби и другие птицы</h3><span class="lvl z">Кровля · рампы</span></div>
          <div class="lat">Признаки: гнёзда под кровлей, помёт на рампах и технике</div>
          <p>Селятся под навесами и над рампами, пачкают помётом продукцию и технику. Подсказываем, какие проёмы закрыть и где нужна защита.</p>
          <div class="bar"><div class="bar-l"><span>Контроль: закрытие проёмов, противоприсадочные системы</span></div></div>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ============ 9. СТОИМОСТЬ ============ -->
<section class="s" id="usloviya">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Цена</div>
      <h2 data-split>Стоимость <em>под ваш объект</em></h2>
      <p class="sub" data-fade>Цену называем после аудита и оценки <span class="nw">пест-риска</span>: она зависит от площади, типа объекта, числа точек контроля и частоты визитов. Состав работ и стоимость фиксируем в договоре.</p>
    </div>
    <div class="kpis" data-group="kpis">
      <div class="card kpi"><b data-count="0" data-suf=" ₽">0 ₽</b><span>Аудит объекта</span></div>
      <div class="card kpi"><b data-count="4">4</b><span>Шага до регулярного обслуживания</span></div>
      <div class="card kpi"><b data-count="6">6</b><span>Документов в пакете по программе</span></div>
      <div class="card kpi"><b data-count="100" data-suf="%">100%</b><span>Средств с госрегистрацией</span></div>
    </div>
    <div class="cases" data-group="cases">
      <article class="card case" data-tilt>
        <div class="case-img"><img width="1200" height="558" decoding="async" src="img/case-food.webp" alt="Мясная продукция на производственной линии" loading="lazy" data-parallax></div>
        <div class="case-b">
          <div class="lbl">Типовая задача · Производство</div>
          <h3>Цех перед аудитом торговой сети</h3>
          <p>Аудит цеха, схема точек контроля, журнал и инструктаж персонала — чтобы к визиту аудитора сети система уже работала и в журнале были записи.</p>
          <div class="case-k"><div><b>Аудит</b><span>Бесплатный выезд</span></div><div><b>6 документов</b><span>Пакет по программе</span></div><div><b class="g">До аудита</b><span>Запуск контроля</span></div></div>
        </div>
      </article>
      <article class="card case" data-tilt>
        <div class="case-img"><img width="1200" height="558" decoding="async" src="img/case-hotel.webp" alt="Гостиничный комплекс" loading="lazy" data-parallax></div>
        <div class="case-b">
          <div class="lbl">Типовая задача · Гостиница</div>
          <h3>Гость сообщил о клопах</h3>
          <p>Срочный осмотр номера и соседних, обработка очага, повторный контроль, затем плановые осмотры номерного фонда и инструктаж горничных.</p>
          <div class="case-k"><div><b>Номер + соседние</b><span>Осмотр</span></div><div><b>Очаг</b><span>Обработка</span></div><div><b class="g">Повторный</b><span>Контроль</span></div></div>
        </div>
      </article>
    </div>
  </div>
</section>

<!-- ============ 10. ВОПРОСЫ ============ -->
<section class="s" id="voprosy">
  <div class="wrap">
    <div class="head">
      <div class="eyebrow" data-eyebrow>Вопросы</div>
      <h2 data-split>Вопросы <em>об обслуживании</em></h2>
    </div>
    <div class="faq">
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a1" id="q1">Что такое IPM?<span class="pm"></span></button><div class="ans" id="a1" role="region" aria-labelledby="q1"><div><p>IPM (Integrated Pest Management) — интегрированная защита от вредителей. Вместо обработок по календарю — постоянный мониторинг, устранение причин появления вредителей и точечные обработки только по показаниям. На этой системе построен наш <span class="nw">пест-менеджмент</span>.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a2" id="q2">Чем пест-менеджмент отличается от пест-контроля?<span class="pm"></span></button><div class="ans" id="a2" role="region" aria-labelledby="q2"><div><p><span class="nw">Пест-контроль</span> — это работы на объекте: осмотры, точки мониторинга, обработки. <span class="nw">Пест-менеджмент</span> — управление всей системой: оценка <span class="nw">пест-риска</span>, программа, анализ данных мониторинга, прогноз численности вредителей и решения по ним. Мы отвечаем и за то, и за другое.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a3" id="q3">Чем постоянный пест-контроль отличается от разовых обработок?<span class="pm"></span></button><div class="ans" id="a3" role="region" aria-labelledby="q3"><div><p>Разовая обработка убивает тех, кто попал под препарат, но не убирает причину. При постоянном контроле точки мониторинга показывают, где и когда появилась активность, а специалист находит пути проникновения и говорит, как их закрыть. Препарата нужно меньше, а у объекта появляется история наблюдений.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a4" id="q4">Что такое оценка пест-риска?<span class="pm"></span></button><div class="ans" id="a4" role="region" aria-labelledby="q4"><div><p>Это разбор объекта по зонам: где вредители могут появиться, откуда прийти и чем это грозит продукции и проверкам. По итогам оценки решаем, сколько нужно точек контроля, где их поставить и как часто приезжать.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a5" id="q5">Как часто специалист приезжает на объект?<span class="pm"></span></button><div class="ans" id="a5" role="region" aria-labelledby="q5"><div><p>Периодичность зависит от типа объекта, вредителей и требований вашей системы качества. Мы предлагаем её по итогам аудита и закрепляем в программе и договоре. Если появился активный очаг, визиты на время учащаем.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a6" id="q6">Что входит в стоимость обслуживания?<span class="pm"></span></button><div class="ans" id="a6" role="region" aria-labelledby="q6"><div><p>Визиты по графику, осмотр и обслуживание точек контроля, записи в журнале, акты и ежемесячный отчёт. Как оплачиваются обработки по результатам мониторинга и выезды вне графика, прописываем в договоре. Точную сумму называем после аудита.</p></div></div></div>
      </div>
      <div class="faq-col" data-group="faq">
        <div class="card qa"><button aria-expanded="false" aria-controls="a7" id="q7">Что делать, если вредителя заметили между визитами?<span class="pm"></span></button><div class="ans" id="a7" role="region" aria-labelledby="q7"><div><p>Позвоните или напишите в мессенджер. Согласуем внеплановый выезд, найдём причину и при необходимости обработаем очаг. Порядок таких выездов закрепляем в договоре.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a8" id="q8">Аудит правда бесплатный? Что будет после него?<span class="pm"></span></button><div class="ans" id="a8" role="region" aria-labelledby="q8"><div><p>Да. Специалист осматривает объект и оценивает <span class="nw">пест-риск</span>, затем мы присылаем программу <span class="nw">пест-контроля</span> и расчёт. Если условия не подойдут, вы ничего не должны.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a9" id="q9">Зачем прогнозировать численность вредителей?<span class="pm"></span></button><div class="ans" id="a9" role="region" aria-labelledby="q9"><div><p>Чтобы действовать до вспышки, а не после неё. Данные мониторинга показывают, в каких зонах численность растёт, а сравнение с прошлыми месяцами — сезонные подъёмы. Прогноз численности вредителей входит в ежемесячный отчёт.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a10" id="q10">Какие документы мы получим?<span class="pm"></span></button><div class="ans" id="a10" role="region" aria-labelledby="q10"><div><p>Договор и программу, схему точек контроля, журнал осмотров, акты выполненных работ, копии СГР и инструкции на средства, отчёт за месяц. Состав пакета уточняем под объект и требования вашей системы качества.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a11" id="q11">Можно работать, не останавливая производство или ресторан?<span class="pm"></span></button><div class="ans" id="a11" role="region" aria-labelledby="q11"><div><p>Да. Осмотр точек не мешает процессу. Обработки, если они нужны, планируем на ночь, выходные или санитарный день. Когда можно возобновить работу, зависит от метода и инструкции к средству — сообщаем об этом заранее.</p></div></div></div>
        <div class="card qa"><button aria-expanded="false" aria-controls="a12" id="q12">Это безопасно для продукции, персонала и гостей?<span class="pm"></span></button><div class="ans" id="a12" role="region" aria-labelledby="q12"><div><p>Приманки — только в закрытых станциях, доступа к ним нет ни у людей, ни у продукции. В производственных зонах ставим ловушки без яда. Применяем только зарегистрированные средства и строго по инструкции.</p></div></div></div>
      </div>
    </div>
  </div>
</section>

<!-- ============ 11. ЗАЯВКА ============ -->
<section class="cta" id="zayavka">
  <div class="cta-bg" data-parallax-bg aria-hidden="true"></div><div class="cta-orb" id="orb" aria-hidden="true"></div>
  <div class="wrap">
    <div>
      <div class="eyebrow" data-eyebrow>Заявка</div>
      <h2 data-split>Начните <em>с бесплатного аудита</em></h2>
      <p class="sub" data-fade>Оставьте контакты — перезвоним, уточним тип и площадь объекта и согласуем день аудита. Аудит ни к чему не обязывает.</p>
      <ul class="cta-list" data-group="ctalist">
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Выезд по Москве и Московской области</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Аудит объекта — бесплатно</li>
        <li><svg aria-hidden="true" focusable="false" class="lucide lucide-circle-check" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" > <circle cx="12" cy="12" r="10" /> <path d="m16 9-5.5 5.5L8 12" /> </svg>Программа и расчёт — после аудита</li>
      </ul>
      <div class="cta-contacts" data-fade>
        <a class="ph" href="tel:+74951043570">+7 (495) 104-35-70</a>
        <div class="msg">
          <a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a>
          <a href="https://t.me/Centr_Dezinfection" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a>
        </div>
      </div>
    </div>
    <form class="form" id="form" novalidate data-form>
      <div class="fbody">
        <h3>Заявка на бесплатный аудит</h3>
        <p class="fs">Заполнение займёт меньше минуты</p>
        <div class="fg">
          <div class="field"><label class="sr-only" for="f-name">Ваше имя</label><input id="f-name" name="name" placeholder="Ваше имя" required autocomplete="name"><small class="ferr">Укажите имя</small></div>
          <div class="field"><label class="sr-only" for="f-company">Компания или объект</label><input id="f-company" name="company" placeholder="Компания или объект" autocomplete="organization"></div>
          <div class="field"><label class="sr-only" for="phone">Телефон</label><input name="phone" id="phone" type="tel" inputmode="tel" placeholder="+7 (___) ___-__-__" required autocomplete="tel"><small class="ferr">Укажите телефон полностью</small></div>
          <div class="field"><label class="sr-only" for="f-email">E-mail</label><input id="f-email" name="email" type="email" placeholder="E-mail" autocomplete="email"><small class="ferr">Проверьте адрес почты</small></div>
          <div class="field full"><label class="sr-only" for="f-type">Тип объекта</label><select id="f-type" name="type" required><option value="" disabled selected>Тип объекта</option><option>Пищевое производство</option><option>Магазин или торговая сеть</option><option>Ресторан или кафе</option><option>Склад, логистика</option><option>Фармацевтическое производство</option><option>Гостиница</option><option>Другое</option></select><small class="ferr">Выберите тип объекта</small></div>
          <div class="field full"><label class="sr-only" for="f-msg">Что беспокоит</label><textarea id="f-msg" name="msg" placeholder="Что беспокоит: вредители, площадь, сроки"></textarea></div>
        </div>
        <button type="submit" class="btn btn-w btn-lg" id="submitBtn"><span class="btn-t">Отправить заявку</span><svg class="btn-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg><i class="spin" aria-hidden="true"></i></button>
        <p class="legal">Нажимая кнопку, вы даёте <a href="soglasie/" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и подтверждаете, что ознакомились с <a href="privacy/" target="_blank" rel="noopener">политикой конфиденциальности</a>.</p>
      </div>
      <div class="ok" role="status" aria-live="polite">
        <svg class="ok-ic" viewBox="0 0 52 52" aria-hidden="true"><circle cx="26" cy="26" r="24" fill="none"/><path fill="none" d="M15 27l7 7 15-16"/></svg>
        <h3>Заявка отправлена</h3><p>Перезвоним в ближайшее рабочее время, чтобы согласовать день аудита.</p>
      </div>
    </form>
  </div>
</section>
</main>

<!-- ============ FOOTER ============ -->
<footer>
  <div class="wrap">
    <div class="ft">
      <div>
        <a href="#top" class="logo" aria-label="ПЕСТКОНТРОЛЬ Центр — наверх"><span class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.5l7.5 3v6c0 5-3.2 8.6-7.5 10-4.3-1.4-7.5-5-7.5-10v-6z"/><circle cx="12" cy="11.5" r="2.6" stroke="#7c86ff"/><path d="M12 6.2v2.7M12 14.1v2.7M6.8 11.5h2.6M14.6 11.5h2.6" stroke="#7c86ff"/></svg></span><span><span class="logo-name">ПЕСТКОНТРОЛЬ</span><span class="logo-sub">Центр</span></span></a>
        <p class="d"><span class="nw">Пест-контроль</span> и <span class="nw">пест-менеджмент</span> по системе IPM для бизнеса в Москве и Московской области: бесплатный аудит, оценка <span class="nw">пест-риска</span>, мониторинг вредителей и отчётность.</p>
      </div>
      <div><h4>Объекты</h4><ul><li><a href="#otrasli">Пищевые производства</a></li><li><a href="#otrasli">Торговые сети</a></li><li><a href="#otrasli">Рестораны и кафе</a></li><li><a href="#otrasli">Склады и логистика</a></li><li><a href="#otrasli">Фармацевтические производства</a></li><li><a href="#otrasli">Гостиницы</a></li></ul></div>
      <div><h4>Навигация</h4><ul><li><a href="#etapy">Этапы работы</a></li><li><a href="#podhod">Метод IPM</a></li><li><a href="#dokumenty">Документы</a></li><li><a href="#usloviya">Цена</a></li><li><a href="#voprosy">Вопросы</a></li></ul></div>
      <div><h4>Контакты</h4><ul><li><a href="tel:+74951043570">+7 (495) 104-35-70</a></li><li><a href="mailto:b2b@pestcontrol-center.ru">b2b@<wbr><span style="white-space:nowrap">pestcontrol-center.ru</span></a></li><li>Пн–Пт: 8:00–20:00</li><li>Срочные выезды: 24/7</li></ul>
        <div class="msg"><a href="https://max.ru/u/f9LHodD0cOIlIUXFkt4KMFP88lD8n4TArBiTcV7RI1XML5c4o39QfsDBXUc" class="max" aria-label="Написать в Max" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M12 3a9 9 0 0 0-7.7 13.7L3 21l4.4-1.2A9 9 0 1 0 12 3zm-3.6 12.3V8.7h1.6l2 2.8 2-2.8h1.6v6.6h-1.7v-3.9L12 14l-1.9-2.6v3.9z"/></svg></a><a href="https://t.me/Centr_Dezinfection" class="tg" aria-label="Написать в Telegram" target="_blank" rel="noopener noreferrer"><svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M21.4 4.3 2.9 11.4c-1.3.5-1.2 1.2-.2 1.5l4.7 1.5 1.8 5.6c.2.6.4.8.9.8.4 0 .6-.2.9-.4l2.3-2.2 4.7 3.5c.9.5 1.5.2 1.7-.8l3.1-14.6c.3-1.3-.5-1.8-1.4-1.5zM9.6 14.1l8.6-5.4c.4-.3.8-.1.5.2l-7.1 6.4-.3 3.3z"/></svg></a></div>
      </div>
    </div>
    <div class="fb"><span>© 2026 ПЕСТКОНТРОЛЬ Центр</span><a href="privacy/">Политика конфиденциальности</a><span>Информация на сайте не является публичной офертой</span></div>
  </div>
</footer>

<div class="mbar" id="mbar">
  <a href="tel:+74951043570" class="c1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>Позвонить</a>
  <a href="#zayavka" class="c2"><span>Бесплатный аудит</span></a>
</div>

<script src="vendor/gsap.min.js" defer></script>
<script src="vendor/ScrollTrigger.min.js" defer></script>
<script src="vendor/lenis.min.js" defer></script>
<script src="app.js?v=20261022v4" defer></script>

<!-- Yandex.Metrika counter -->
<script type="text/javascript">
    (function(m,e,t,r,i,k,a){
        m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
        m[i].l=1*new Date();
        for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
        k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)
    })(window, document,'script','https://mc.yandex.ru/metrika/tag.js?id=113675622', 'ym');

    ym(113675622, 'init', {ssr:true, webvisor:true, clickmap:true, ecommerce:"dataLayer", referrer: document.referrer, url: location.href, accurateTrackBounce:true, trackLinks:true});
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/113675622" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->

</body>
</html>
